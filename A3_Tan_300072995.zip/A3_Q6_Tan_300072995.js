var re = document.getElementById("result");
function printLatinWord(w){
    re.innerHTML = re.innerHTML + w.substring[1] + w[0]+"ay"
}
function pigg(){
    var input = document.getElementById("English");
    var w = input.value.split(' ')
    w.forEach(printLatinWord(w));
    re.innerHTML = re.innerHTML +"\n"
}
function act(){
    pigg();
    printLatinWord();
}