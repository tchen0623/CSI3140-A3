function prime(){
    var numbers = new Array();
    numbers[0]=0;
    numbers[1]=0;
    for(i = 2;i<1000;i++){
        numbers[i] = 1;
    }
    for(k=2;k<numbers.length;k++){
            for(j=k+1;j<numbers.length;j++){
                if(numbers[j]!=0){
                if(j%k==0){
                    numbers[j]=0;
                }
                }
            }
        }
    
    for(l=2;l<numbers.length;l++){
        if(numbers[l] == 1){
            document.write(l+"<br/>");
        }
    }
    }