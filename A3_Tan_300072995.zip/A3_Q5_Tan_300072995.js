var ticks =0;
var Tsquare = 0;
var Hsquare = 0;
var i;
function race(){
        i =Math.floor(Math.random()*10);
        Tmove(i);
        Hmove(i);
        if(Tsquare == Hsquare){
            document.getElementById("result").innerHTML="OUCH!!";
        }
        ticks++;
}
function Tmove(i){
    if(i<=5){
        Tsquare = Tsquare+3;
    }
    else if(i>=6 && i<=7){
        Tsquare = Tsquare - 6;
    }else{
        Tsquare = Tsquare +1;
    }
}
function Hmove(i){
    if(i<=2){
        Hsquare = Hsquare +0;
    }
    else if(i>=3 && i <=4){
        Hsquare = Hsquare +9;
    }else if(i==5){
        Hsquare = Hsquare -12;
    }else if( i>=6 && i <=8){
        Hsquare = Hsquare +1;
    }else{
        Hsquare = Hsquare -2;
    }
}
function start(){
while(Tsquare && Hsquare != 70){
    var intv = setInterval(race(),1000);
}
clearInterval(intv);
if(Tsquare > Hsquare){
    document.getElementById("result").innerHTML="TORTOISE WINS";
}else if (Hsquare>Tsquare){
    document.getElementById("result").innerHTML="HARE WINS!";
}else{
    document.getElementById("result").innerHTML="TIE!!";
}
document.getElementById("ticks").innerHTML=ticks;
}